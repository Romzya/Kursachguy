from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from datetime import datetime, timedelta
import uuid
import hashlib
import json
import os

app = Flask(__name__)
app.secret_key = 'paywave_secret_key_2024'

# ─── In-memory data store ───────────────────────────────────────────────────

users = {
    'user1': {
        'id': 'user1',
        'name': 'Алексей Петров',
        'email': 'alex@example.com',
        'password': hashlib.md5('pass123'.encode()).hexdigest(),
        'balance': 45230.50,
        'card': '**** **** **** 4582',
        'avatar': 'AP',
        'verified': True,
        'created': '2024-01-15'
    },
    'user2': {
        'id': 'user2',
        'name': 'Мария Соколова',
        'email': 'maria@example.com',
        'password': hashlib.md5('pass456'.encode()).hexdigest(),
        'balance': 12800.00,
        'card': '**** **** **** 7731',
        'avatar': 'МС',
        'verified': True,
        'created': '2024-02-20'
    }
}

admins = {
    'admin': {
        'password': hashlib.md5('admin123'.encode()).hexdigest(),
        'name': 'Администратор'
    }
}

transactions = [
    {
        'id': str(uuid.uuid4())[:8].upper(),
        'from_user': 'user2',
        'to_user': 'user1',
        'amount': 5000.00,
        'type': 'transfer',
        'status': 'completed',
        'description': 'Перевод за услуги',
        'date': (datetime.now() - timedelta(hours=2)).strftime('%Y-%m-%d %H:%M')
    },
    {
        'id': str(uuid.uuid4())[:8].upper(),
        'from_user': 'user1',
        'to_user': None,
        'amount': 1200.00,
        'type': 'payment',
        'status': 'completed',
        'description': 'Оплата ЖКХ',
        'date': (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d %H:%M')
    },
    {
        'id': str(uuid.uuid4())[:8].upper(),
        'from_user': 'user1',
        'to_user': 'user2',
        'amount': 800.00,
        'type': 'transfer',
        'status': 'pending',
        'description': 'Долг',
        'date': (datetime.now() - timedelta(days=2)).strftime('%Y-%m-%d %H:%M')
    },
    {
        'id': str(uuid.uuid4())[:8].upper(),
        'from_user': None,
        'to_user': 'user1',
        'amount': 15000.00,
        'type': 'deposit',
        'status': 'completed',
        'description': 'Пополнение счёта',
        'date': (datetime.now() - timedelta(days=3)).strftime('%Y-%m-%d %H:%M')
    },
    {
        'id': str(uuid.uuid4())[:8].upper(),
        'from_user': 'user2',
        'to_user': None,
        'amount': 450.00,
        'type': 'payment',
        'status': 'failed',
        'description': 'Оплата интернета',
        'date': (datetime.now() - timedelta(days=4)).strftime('%Y-%m-%d %H:%M')
    },
]

# ─── Auth routes ─────────────────────────────────────────────────────────────

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login_input = request.form.get('email', '').strip()
        password = hashlib.md5(request.form.get('password', '').encode()).hexdigest()
        for uid, user in users.items():
            if (user['email'] == login_input or uid == login_input) and user['password'] == password:
                session['user_id'] = uid
                flash('Добро пожаловать, ' + user['name'] + '!', 'success')
                return redirect(url_for('dashboard'))
        flash('Неверный email или пароль', 'error')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        for u in users.values():
            if u['email'] == email:
                flash('Email уже зарегистрирован', 'error')
                return render_template('register.html')
        uid = 'user' + str(len(users) + 1)
        initials = ''.join([w[0] for w in name.split()[:2]]).upper()
        users[uid] = {
            'id': uid,
            'name': name,
            'email': email,
            'password': hashlib.md5(password.encode()).hexdigest(),
            'balance': 0.0,
            'card': '**** **** **** ' + str(1000 + len(users)),
            'avatar': initials,
            'verified': False,
            'created': datetime.now().strftime('%Y-%m-%d')
        }
        session['user_id'] = uid
        flash('Аккаунт создан успешно!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# ─── User routes ─────────────────────────────────────────────────────────────

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user = users[session['user_id']]
    user_txns = [t for t in transactions if t['from_user'] == user['id'] or t['to_user'] == user['id']]
    user_txns = sorted(user_txns, key=lambda x: x['date'], reverse=True)[:5]
    stats = {
        'total_in': sum(t['amount'] for t in transactions if t['to_user'] == user['id'] and t['status'] == 'completed'),
        'total_out': sum(t['amount'] for t in transactions if t['from_user'] == user['id'] and t['status'] == 'completed'),
        'pending': sum(1 for t in transactions if (t['from_user'] == user['id'] or t['to_user'] == user['id']) and t['status'] == 'pending')
    }
    return render_template('dashboard.html', user=user, transactions=user_txns, stats=stats)

@app.route('/send', methods=['GET', 'POST'])
def send():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user = users[session['user_id']]
    if request.method == 'POST':
        recipient_email = request.form.get('recipient')
        amount = float(request.form.get('amount', 0))
        description = request.form.get('description', 'Перевод')
        recipient = None
        for u in users.values():
            if u['email'] == recipient_email and u['id'] != user['id']:
                recipient = u
                break
        if not recipient:
            flash('Получатель не найден', 'error')
        elif amount <= 0:
            flash('Введите корректную сумму', 'error')
        elif amount > user['balance']:
            flash('Недостаточно средств', 'error')
        else:
            users[user['id']]['balance'] -= amount
            users[recipient['id']]['balance'] += amount
            txn = {
                'id': str(uuid.uuid4())[:8].upper(),
                'from_user': user['id'],
                'to_user': recipient['id'],
                'amount': amount,
                'type': 'transfer',
                'status': 'completed',
                'description': description,
                'date': datetime.now().strftime('%Y-%m-%d %H:%M')
            }
            transactions.insert(0, txn)
            flash(f'Перевод {amount:.2f} ₽ на счёт {recipient["name"]} выполнен!', 'success')
            return redirect(url_for('dashboard'))
    other_users = [u for uid, u in users.items() if uid != user['id']]
    return render_template('send.html', user=user, other_users=other_users)

@app.route('/history')
def history():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user = users[session['user_id']]
    user_txns = [t for t in transactions if t['from_user'] == user['id'] or t['to_user'] == user['id']]
    user_txns = sorted(user_txns, key=lambda x: x['date'], reverse=True)
    for t in user_txns:
        if t['to_user'] and t['to_user'] in users:
            t['to_name'] = users[t['to_user']]['name']
        if t['from_user'] and t['from_user'] in users:
            t['from_name'] = users[t['from_user']]['name']
    return render_template('history.html', user=user, transactions=user_txns)

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user = users[session['user_id']]
    if request.method == 'POST':
        users[user['id']]['name'] = request.form.get('name', user['name'])
        flash('Профиль обновлён', 'success')
        return redirect(url_for('profile'))
    return render_template('profile.html', user=user)

# ─── Admin routes ─────────────────────────────────────────────────────────────

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = hashlib.md5(request.form.get('password', '').encode()).hexdigest()
        if username in admins and admins[username]['password'] == password:
            session['admin'] = username
            return redirect(url_for('admin_dashboard'))
        flash('Неверные данные администратора', 'error')
    return render_template('admin/login.html')

@app.route('/admin')
@app.route('/admin/dashboard')
def admin_dashboard():
    if 'admin' not in session:
        return redirect(url_for('admin_login'))
    total_balance = sum(u['balance'] for u in users.values())
    total_txns = len(transactions)
    completed = sum(1 for t in transactions if t['status'] == 'completed')
    failed = sum(1 for t in transactions if t['status'] == 'failed')
    pending = sum(1 for t in transactions if t['status'] == 'pending')
    total_volume = sum(t['amount'] for t in transactions if t['status'] == 'completed')
    recent_txns = sorted(transactions, key=lambda x: x['date'], reverse=True)[:8]
    for t in recent_txns:
        if t.get('to_user') and t['to_user'] in users:
            t['to_name'] = users[t['to_user']]['name']
        if t.get('from_user') and t['from_user'] in users:
            t['from_name'] = users[t['from_user']]['name']
    return render_template('admin/dashboard.html',
        users=users, transactions=recent_txns,
        stats={
            'users': len(users), 'total_balance': total_balance,
            'total_txns': total_txns, 'completed': completed,
            'failed': failed, 'pending': pending, 'total_volume': total_volume
        })

@app.route('/admin/users')
def admin_users():
    if 'admin' not in session:
        return redirect(url_for('admin_login'))
    return render_template('admin/users.html', users=users)

@app.route('/admin/users/block/<uid>')
def admin_block_user(uid):
    if 'admin' not in session:
        return redirect(url_for('admin_login'))
    if uid in users:
        users[uid]['verified'] = not users[uid].get('verified', True)
        status = 'разблокирован' if users[uid]['verified'] else 'заблокирован'
        flash(f'Пользователь {users[uid]["name"]} {status}', 'success')
    return redirect(url_for('admin_users'))

@app.route('/admin/transactions')
def admin_transactions():
    if 'admin' not in session:
        return redirect(url_for('admin_login'))
    txns = sorted(transactions, key=lambda x: x['date'], reverse=True)
    for t in txns:
        if t.get('to_user') and t['to_user'] in users:
            t['to_name'] = users[t['to_user']]['name']
        else:
            t['to_name'] = 'Система'
        if t.get('from_user') and t['from_user'] in users:
            t['from_name'] = users[t['from_user']]['name']
        else:
            t['from_name'] = 'Система'
    return render_template('admin/transactions.html', transactions=txns)

@app.route('/admin/transactions/update/<tid>/<status>')
def admin_update_txn(tid, status):
    if 'admin' not in session:
        return redirect(url_for('admin_login'))
    for t in transactions:
        if t['id'] == tid:
            t['status'] = status
            flash(f'Транзакция {tid} обновлена', 'success')
            break
    return redirect(url_for('admin_transactions'))

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    return redirect(url_for('admin_login'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
